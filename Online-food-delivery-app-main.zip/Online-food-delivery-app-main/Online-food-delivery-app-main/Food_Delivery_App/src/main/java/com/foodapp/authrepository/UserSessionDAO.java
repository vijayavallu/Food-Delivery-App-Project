package com.foodapp.authrepository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface UserSessionDAO extends JpaRepository<UserSessionDAO, Integer> {
	
	public Optional<UserSessionDAO> findByUserId(Integer userId);
	
	public Optional<UserSessionDAO> findByUUID(String uuid);

}
