package com.foodapp.authrepository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SignUpModelDAO extends JpaRepository<SignUpModelDAO, Integer> {
	
	public Optional<SignUpModelDAO> findByUserName(String userName);

}
