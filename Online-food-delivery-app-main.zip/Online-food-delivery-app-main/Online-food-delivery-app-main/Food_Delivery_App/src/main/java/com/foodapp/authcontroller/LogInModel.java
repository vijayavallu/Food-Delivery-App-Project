package com.foodapp.authcontroller;

public class LogInModel {

}
