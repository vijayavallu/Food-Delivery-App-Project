package com.foodapp.exceptions;

public class CustomerException extends Exception {
	
	public CustomerException() {
		// TODO Auto-generated constructor stub
	}
	
	
	public CustomerException(String message) {
		super(message);
	}

}
